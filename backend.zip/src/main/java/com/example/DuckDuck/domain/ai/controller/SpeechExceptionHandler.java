package com.example.DuckDuck.domain.ai.controller;

import lombok.extern.slf4j.Slf4j;
import com.example.DuckDuck.domain.ai.exception.AzureSpeechException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeoutException;

@Component
@Slf4j
public class SpeechExceptionHandler {

    // Map<String, Object> → Map<String, String>
    public ResponseEntity<Map<String, String>> handle(Throwable ex, String scriptId) {
        Throwable cause = (ex instanceof CompletionException) ? ex.getCause() : ex;

        if (cause instanceof TimeoutException) {
            log.error("[SCRIPT-{}] 발음 평가 타임아웃", scriptId);

            Map<String, String> body = new HashMap<>();
            body.put("scriptId", scriptId);
            body.put("errorCode", "TIMEOUT");
            body.put("message", "평가 시간 초과");

            return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body(body);
        }

        if (cause instanceof AzureSpeechException) {
            log.error("[SCRIPT-{}] Azure 오류: {}", scriptId, cause.getMessage());

            Map<String, String> body = new HashMap<>();
            body.put("scriptId", scriptId);
            body.put("errorCode", "AZURE_ERROR");
            body.put("message", cause.getMessage());

            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(body);
        }

        log.error("[SCRIPT-{}] 발음 평가 실패", scriptId, cause);

        Map<String, String> body = new HashMap<>();
        body.put("scriptId", scriptId);
        body.put("errorCode", "SERVER_ERROR");
        body.put("message", "서버 오류");

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }
}