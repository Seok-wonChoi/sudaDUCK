import styles from './MiniGameLayout.module.css';
import AppHeader from '@/components/layout/AppHeader/AppHeader';
import GameHeader from '../common/GameHeader';
import ProgressBar from '../common/ProgressBar';
import ParticipantList from '../common/ParticipantList';

export default function MiniGameLayout({
  children,
  showGameHeader = true,
  title = '빈칸 채우기',
  timer = '0:00',
  progress = 0,
  totalProgress = 100,
  participants = [],
  voiceLevels = {},
  userName = 'user',
  onExit,
  // 로고 클릭 나가기 관련 props
  logoExitMessage,
  onLogoExit,
  // 리뷰 모드 관련
  isReviewMode = false,
  onComplete,
}) {
  return (
    <div className={styles.layout}>
      <AppHeader
        userName={userName}
        logoExitMessage={logoExitMessage}
        onLogoExit={onLogoExit || onExit}
      />

      <main className={styles.main}>
        {showGameHeader && (
          <>
            <GameHeader title={title} timer={timer} />
            <ProgressBar current={progress} total={totalProgress} />
          </>
        )}

        <div className={styles.content}>
          {children}
        </div>
      </main>

      <footer className={styles.footer}>
        <ParticipantList 
          participants={participants} 
          voiceLevels={voiceLevels}
        />
        {/* 리뷰 모드일 때 완료 버튼 표시 */}
        {isReviewMode && onComplete && (
          <button className={styles.completeButton} onClick={onComplete}>
            완료
          </button>
        )}
      </footer>
    </div>
  );
}
